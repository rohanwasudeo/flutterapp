package mtis.com.flutter_appdemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
